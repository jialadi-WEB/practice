(function (window, $) {
  'use strict';
  // Your starting point. Enjoy the ride!
  // 获取元素
  const $newtodo = $('.new-todo')
  /***
   * 功能一：
   *  查看本地存储里面是否有数据，然后进行相应的渲染
   * 
   */
  var todos;
  todos = JSON.parse(localStorage.getItem('todos') || '[]')
  var itemarr = todos.filter((item) => item.completed !== true)
  // 上来先计算一下count，先给count赋值
  var count = itemarr.length > 0 ? itemarr.length : 0;

  // 加载内容，封装函数
  function gettemplate(itemArr) {
    // 上来先将之前那个ul里面的内容清空
    $('.todo-list').html("")
    // 重新渲染数据
    if (itemArr && itemArr.length > 0) {
      for (var j = 0; j < itemArr.length; j++) {
        var id = itemArr[j].id
        var value = itemArr[j].title
        var completed = itemArr[j].completed
        let newli = `<li data-id=${id} class=${completed ? 'completed' : ""}>
        <div class="view">
          <input class="toggle" type="checkbox" ${completed ? "checked" : ""}>
          <label>${value}</label>
          <button class="destroy"></button>
       </div>
       <input class="edit" value=${value}>
      </li>`
        // 添加到ul里面
        $('.todo-list').append(newli)
        // 获取剩下的个数
        leftitem(count)
        // 是否显示clear-complete
        showclearbtn()
      }
    }
  }

  /***
   * 功能二：
   *  用户通过表单输入内容,然后按住回车键添加内容
   *   todos=[
   *     {id:1,title:表单的值,completed:false}
   *   ]
   * 
   * 
   */
  $newtodo.on('keyup', function (e) {
    if (e.keyCode === 13) {
      $('.footer').show();
      // 获取输入的内容
      let $newvalue = $(this).val()
      // 需要设置id
      var id = (todos.length) > 0 ? (todos[todos.length - 1].id + 1) : 1
      // 添加一个对象
      todos.push({ id: id, title: $newvalue, completed: false })
      // 需要将数据进行本地存储
      localStorage.setItem('todos', JSON.stringify(todos))
      // 如果内容为空，就清空
      if ($newvalue.trim().length === 0) {
        return;
      }
      todos = JSON.parse(localStorage.getItem('todos'))
      /**
       * 这里的bug就是不能调用渲染的模板的函数，否则添加的时候就会出现问题
       * 所以这里还是调用hash封装的函数
       * 
       */
      changehash()

      // 之后清空表单的内容
      $(this).val("")

      // 计算剩余的个数
      count++;
      leftitem(count);
    }
  })

  /***
   * 
   * 功能三：
   * 点击前面的复选框，给li标签决定是否添加类名completed
   * 
   * 
   */

  // 通过事件委托的方式
  $('.todo-list').on('click', '.toggle', function () {
    // 如果是选中则不选中，如果是不选中则选中
    let check = $(this).prop('checked')
    // console.log(check)
    let dataid = $(this).parent().parent().data('id')
    // 去寻找和dataid一样的id,进行值的修改
    let item = todos.find((item) => item.id === dataid)
    // 如果为真，给父元素的父元素添加类名
    if (check) {
      $(this).parent().parent().addClass('completed')
      // 并且将对应本地的存储对应的数据的completed的布尔值置为，true
      item.completed = true
      localStorage.setItem('todos', JSON.stringify(todos))
      // 计算剩余的数量
      count--;
      leftitem(count);
      // 是否显示clear-complete
      showclearbtn()
    } else {
      // 如果为假，给父元素的父元素移除类名
      $(this).parent().parent().removeClass('completed')
      // 并且将对应本地的存储对应的数据的completed的布尔值置为，false
      item.completed = false
      localStorage.setItem('todos', JSON.stringify(todos))
      // 计算剩余的数量
      count++;
      leftitem(count);
      // 是否显示clear-complete
      showclearbtn()

    }

  })


  /***
  * 
  * 功能四：
  * 求剩下的值的函数的封装。剩下的值，等于的是数据里面得completed得值是false的数据的个数
  * 
  */
  // 设置剩下的值
  function leftitem(count) {
    // 设置左边剩下的值
    $('.todo-count').find('strong').text(count)
  }

  /****
   * 功能五：
   * 点击后面的小叉号，删除当前的这个li从ul中，并且将对应的数据从本地存储中删除
   */


  // 还是通过事件委托的方式
  $('.todo-list').on('click', '.destroy', function () {
    // 需要先去判断当前的li元素是否有completed这个类名，如果有，那么不需要调用函数，如果没有，需要调用函数
    let dataid = $(this).parent().parent().data('id')
    // 去寻找和dataid一样的id,进行值的修改
    let index = todos.findIndex((item) => item.id === dataid)
    //这个是判断父级li上面是否有completed这个类名
    var iscomclass = $(this).parent().parent().hasClass('completed')
    //如果没有这个类名，点击需要减减
    if (!iscomclass) {
      count--;
      // console.log(count)
      leftitem(count);
    }
    // 将当前的li从ul中删除
    $(this).parent().parent().remove();
    //将数据从本地存储种删除
    todos.splice(index, 1)
    localStorage.setItem('todos', JSON.stringify(todos))

  })


  /***
   * 功能六，点击clear-completed按钮，实现将completed的值为true的数据进行清除，并且从新调用渲染模板的函数
   */

  $('.clear-completed').on('click', function () {
    // 找到本地存储中的数据里面的completed的值为true的，然后删除，在进行数据的重新渲染
    let itemArr = todos.filter((item) => item.completed !== true)
    // 将取出来的数组，进行删除从todos里面
    localStorage.setItem('todos', JSON.stringify(itemArr))

    //  console.log(localStorage.getItem('todos'))
    todos = JSON.parse(localStorage.getItem('todos'))
    // 如果获取到的数据的长度是0，那么将footer删除
    if (todos.length !== 0) {
      $(this).hide();
    }

    // 根据新的数据重新渲染
    gettemplate(todos)

    // 无论怎么都是自动获取焦点
    $('.new-todo').focus();
    // 是否显示clear-complete
    showclearbtn()

  })

  /***
   * 功能七：
   *   根据hash值得不同，渲染不同得内容
   *
   */

  // 上来先加载一下
  changehash()
  // 当hash值改变的时候，再次加载
  window.onhashchange = changehash

  // hash值得改变获取来获取内容
  function changehash() {

    // 获取的hash的值，如果没有hash，那么就默认hash值为all的
    var hash = location.hash ? location.hash : "#/all"
    // 根据不同的hash值，不同的a添加类名selected
    $(`.filters li a[href="${hash}"]`).addClass('selected').parent().siblings().find('a').removeClass('selected')
    hash = hash.slice(2)
    switch (hash) {
      case "all": gettodoslist('all'); break;
      case "active": gettodoslist('active'); break;
      case "completed": gettodoslist('completed'); break;

    }
  }


  // 根据不同的a，获取不同的内容
  function gettodoslist(url = 'all') {
    // 无论怎么都是自动获取焦点
    $('.new-todo').focus();
    if (url) {
      // 重新获取数据
      todos = JSON.parse(localStorage.getItem('todos') || '[]')
      gettemplate(todos)
    }
    if (url == 'active') {
      // 重新获取数据
      todos = JSON.parse(localStorage.getItem('todos'))
      // 渲染的是completed:false的
      // 渲染的是completed:true的
      let itemArr = todos.filter((item) => item.completed !== true)
      gettemplate(itemArr)
    }
    if (url == 'completed') {
      // 渲染的是completed:true的
      // 重新获取数据
      todos = JSON.parse(localStorage.getItem('todos'))
      let itemArr = todos.filter((item) => item.completed == true)
      // 渲染之前，需要将之前的内容清空
      gettemplate(itemArr)
    }
  }

  /***
   * 功能八：
   * 双击 <label> （某个任务项）进入编辑状态（在 <li> 上通过 .editing 进行切换状态）
    进入编辑状态后输入框显示原内容，并会自动获取编辑焦点
    输入状态按 Esc 取消编辑，editing 样式应该被移除
     按 Enter 键 或 失去焦点时 保存改变数据，移除 editing 样式 
   */

  $('.todo-list').on('dblclick', 'label', function () {
    // 获取当前的li的自定义属性id
    var dataid = $(this).parent().parent().data('id')
    var todos = JSON.parse(localStorage.getItem('todos'))
    // 找到本地存储中对应的id的那一项，
    var item = todos.find((item) => item.id === dataid)
    // 给当前的li在添加一个类名
    $(this).parent().parent().addClass('editing')
    // 并且编辑的输入框自动获取焦点
    $('.edit').focus();
    //按住Esc键会取消编辑
    $('.todo-list .edit').blur(function () {
      // 按 Enter 键 或 失去焦点时 保存改变数据，移除 editing 样式
      // 获取修改之后编辑表单的内容
      var editvalue = $(this).val();
      // 将保存的数据在本地存储中进行对应的修改
      item.title = editvalue
      // 再次更改本地存储的数据
      localStorage.setItem('todos', JSON.stringify(todos))
      // 失去焦点之后，需要将对应的li上面的编辑的样式进行移除
      $(this).parent().removeClass('editing')
      // 需要重新调用render函数
      todos = JSON.parse(localStorage.getItem('todos'))
      gettemplate(todos)

    })

    $('.todo-list .edit').keyup(function (e) {
      if (e.keyCode === 13) {
        var editvalue = $(this).val();
        // 将保存的数据在本地存储中进行对应的修改
        item.title = editvalue
        // 再次更改本地存储的数据
        localStorage.setItem('todos', JSON.stringify(todos))
        // 失去焦点之后，需要将对应的li上面的编辑的样式进行移除
        $(this).parent().removeClass('editing')
        // 需要重新调用render函数
        todos = JSON.parse(localStorage.getItem('todos'))
        gettemplate(todos)
      }

      // 如果键盘码是27代表的是按住的是esc键，
      // 输入状态按 Esc 取消编辑，editing 样式应该被移除
      // console.log(e.keyCode===27)
      if (e.keyCode === 27) {
        // 将父级li上面的类名进行删除
        $(this).parent().removeClass('editing')
      }
    })


  })
  /***
   * 功能九：
   * 点击箭头toggle-all也是一个input,实现数据的全选和全不选,不全选
   * 
   */
  $('.toggle-all').click(function () {
    // 当点击箭头的时候，将所有的completed为fasle的设置为true,如果是true,设置为false
    todos = JSON.parse(localStorage.getItem('todos'))
    // 获取当前的input的选中状态
    var allcheck = $(this).prop('checked')
    // 设置对应的li下面的input的选中状态和allcheck一样,并且所有的li需要加上completed这个类名
    $('.todo-list input').prop('checked', allcheck)
    // 如果是都选中状态，需要给每个li添加一个completed的类名，如果都不选中的话，那么就移除这个类名
    allcheck ? $('.todo-list li').addClass('completed') : $('.todo-list li').removeClass('completed')
    // 将todos所有的completed的状态，设置成和allcheck一样的
    todos.forEach((item) => item.completed = allcheck)
    //并且要将本地存储中的数据进行对应的修改
    localStorage.setItem('todos', JSON.stringify(todos))
    // 需要在这里再次计算剩下的个数
    // 如果是全部选中那么leftitem(count) 的值就是0，如果是全部不选中，那么就是整个长度
    count = allcheck ? 0 : todos.length;
    leftitem(count)
    // 是否展示clear-completed这个按钮
    showclearbtn()

  })

  $('.todo-list').on('change', 'input', function () {
    // 这个是当点击li下面的input的时候，只有当所有的li下面的input选中的时候，那个全选的input才选中，否则不选中
    // 计算选中的长度和总长度是否相等
    todos = JSON.parse(localStorage.getItem('todos'))
    var alllength = todos.length;
    // 求出选中的长度
    var checklength = todos.filter((item) => item.completed === true).length
    // 设置全部选中的状态
    $('.toggle-all').prop('checked', alllength === checklength ? true : false)
  })

  /***
   * 功能十：根据数据里面是否有completed是true来展示，Clear completed
   * .clear-completed
   */
  function showclearbtn() {
    todos = JSON.parse(localStorage.getItem('todos'))
    var iscompletedlength = todos.filter((item) => item.completed === true).length
    iscompletedlength > 0 ? $('.footer .clear-completed').show() : $('.footer .clear-completed').hide()
  }
})(window, jQuery);
